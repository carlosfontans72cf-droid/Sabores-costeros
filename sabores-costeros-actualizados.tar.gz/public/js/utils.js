// Utilidades y Multi-idioma - Sabores Costeros

// ========== SISTEMA DE TRADUCCIONES COMPLETO ==========
const traducciones = {
  es: {
    // Login
    'app-subtitle': 'Descubrí los mejores restaurantes de la costa',
    'label-email': 'Email',
    'label-password': 'Contraseña',
    'label-nombre': 'Nombre',
    'label-apellido': 'Apellido',
    'label-email-reg': 'Email',
    'label-password-reg': 'Contraseña',
    'placeholder-email': 'tu@email.com',
    'placeholder-password': 'Contraseña',
    'placeholder-nombre': 'Tu nombre',
    'placeholder-apellido': 'Tu apellido',
    'placeholder-email-reg': 'tu@email.com',
    'placeholder-password-reg': 'Mínimo 6 caracteres',
    'placeholder-codigo': 'Ej: EMB001',
    'btn-login': 'Iniciar Sesión',
    'btn-register': 'Crear cuenta',
    'text-no-account': '¿No tenés cuenta?',
    'link-register': 'Registrate',
    'text-have-account': '¿Ya tenés cuenta?',
    'link-login': 'Iniciá sesión',
    'role-cliente': ' Turista / Cliente',
    'role-restaurante': '🏪 Dueño de restaurante',
    'role-embajador': '🌟 Embajador (Promotor)',
    'label-role': 'Quiero registrarme como:',
    'label-codigo-emb': 'Tu código de Embajador (opcional)',
    'legal-text': 'Al registrarte, aceptás nuestra',
    'error-empty-fields': 'Completá todos los campos',
    'error-weak-password': 'Contraseña mínimo 6 caracteres',
    'error-email-exists': 'Email ya registrado',
    'error-invalid-email': 'Email inválido',
    'error-wrong-password': 'Email o contraseña incorrectos',
    'error-user-not-found': 'No existe cuenta con ese email',
    'error-account-deactivated': 'Cuenta desactivada',

    // Navbar y botones globales
    'nav-logout': 'Salir',
    'nav-admin': '👑 Panel Administrador',
    'nav-cliente': '️ Sabores Costeros',
    'nav-restaurante': '🍽️ Mi Restaurante',
    'nav-partner': '🤝 Panel Partner',
    'nav-embajador': '🌟 Panel Embajador',
    'nav-promotor': '💼 Panel Promotor',
    'nav-user-loading': 'Cargando...',

    // Admin tabs
    'tab-crear': '➕ Crear Usuario',
    'tab-aprobaciones': '✅ Aprobaciones',
    'tab-usuarios': '👥 Usuarios',
    'tab-pagos': '💰 Comisiones',
    'tab-sorteo': '🎉 Sorteo',
    'tab-configuracion': '⚙️ Configuración',
    'section-crear': '➕ Crear Admin / Partner / Embajador',
    'section-aprobaciones': '✅ Restaurantes Pendientes de Aprobación',
    'section-usuarios': '👥 Gestión de Usuarios',
    'section-pagos': ' Registro de Comisiones',
    'section-sorteo': '🎉 Sorteo Semanal',
    'section-config': '⚙️ Configuración de Comisiones',
    'no-aprobaciones': 'No hay aprobaciones pendientes',
    'no-usuarios': 'Sin usuarios',
    'no-pagos': 'Sin pagos registrados',
    'label-new-nombre': 'Nombre',
    'label-new-apellido': 'Apellido',
    'label-new-email': 'Email',
    'label-new-password': 'Contraseña',
    'label-new-role': 'Rol',
    'label-new-codigo': 'Código único',
    'placeholder-new-nombre': 'Nombre',
    'placeholder-new-apellido': 'Apellido',
    'placeholder-new-email': 'email@ejemplo.com',
    'placeholder-new-password': 'Mínimo 6 caracteres',
    'placeholder-new-codigo': 'Ej: REVISTA01, EMB001',
    'role-admin': '🔑 Administrador',
    'role-partner': '🤝 Partner (Revista/Influencer/Radio)',
    'role-embajador-select': ' Embajador (Promotor)',
    'btn-crear': '✅ Crear Usuario',
    'btn-activar': 'Activar',
    'btn-desactivar': 'Desactivar',
    'btn-aprobar': '✅ Aprobar',
    'btn-rechazar': '❌ Rechazar',
    'config-comision-total': 'Comisión total por cubierto (USD)',
    'config-comision-fundador': 'Comisión Fundador (USD)',
    'config-comision-embajador': 'Comisión Embajador (USD)',
    'config-comision-partner': 'Comisión Partner (USD)',
    'btn-guardar-config': ' Guardar Configuración',
    'config-saved': 'Configuración guardada correctamente',
    'user-activado': 'Usuario activado',
    'user-desactivado': 'Usuario desactivado',
    'restaurante-aprobado': 'Restaurante aprobado',
    'restaurante-rechazado': 'Restaurante rechazado',
    'resumen-comisiones': '📊 Resumen de Comisiones',
    'total-recaudado': '💰 Total recaudado',
    'total-fundador': '👑 Fundador (vos)',
    'total-embajadores': ' Embajadores',
    'total-partners': '🤝 Partners',

    // Cliente tabs
    'tab-restaurantes': '🍽️ Restaurantes',
    'tab-reservas': '📋 Mis Reservas',
    'tab-sorteo-tab': '🎉 Sorteo',
    'tab-perfil': '👤 Perfil',
    'banner-sorteo-title': ' ¡SORTEO SEMANAL!',
    'banner-sorteo-desc': 'Validá tu código al llegar y participá por una <strong>cena gratis para 4 personas</strong>',
    'banner-sorteo-sub': '🏆 Sorteo todos los sábados · 📍 En los mejores restaurantes de la costa',
    'section-restaurantes': '🍽️ Restaurantes de la Costa',
    'section-mis-reservas': '📋 Mis Reservas',
    'section-perfil': '👤 Mi Perfil',
    'no-restaurantes': 'Aún no hay restaurantes disponibles',
    'no-reservas': 'No tenés reservas activas',
    'btn-reservar': 'Reservar Mesa',
    'label-fecha': 'Fecha',
    'label-hora': 'Hora',
    'label-personas': 'Cantidad de personas',
    'btn-confirmar-reserva': 'Confirmar Reserva',
    'reserva-confirmada-title': '🎉 ¡Reserva Confirmada!',
    'reserva-codigo-label': 'Tu código de reserva:',
    'reserva-presentar': '📱 Presentá este código al llegar',
    'reserva-sorteo-info': '🎉 Validalo al llegar y participá del <strong>sorteo semanal</strong> de una cena gratis',
    'btn-entendido': 'Entendido',
    'btn-cerrar': 'Cerrar',
    'reserva-estado-confirmada': 'Confirmada',
    'reserva-estado-asistida': 'Asistida ✅',
    'reserva-estado-cancelada': 'Cancelada',
    'estado-label': 'Estado',
    'reserva-presentar-banner': ' Presentá este código al llegar',
    'reserva-sorteo-banner': '🎉 Validalo para participar del sorteo semanal de una cena gratis',
    'btn-compartir-whatsapp': ' Compartir por WhatsApp',
    'btn-como-llegar': '🗺️ Cómo llegar',
    'perfil-nombre-label': 'Nombre',
    'perfil-email-label': 'Email',
    'perfil-idioma-label': 'Idioma',
    'perfil-cambiar-idioma': 'Cambiar idioma',
    'btn-guardar-idioma': 'Guardar idioma',
    'idioma-es': '🇪🇸 Español',
    'idioma-pt': '🇧 Português',
    'idioma-en': '🇺🇸 English',

    // Sorteo
    'sorteo-titulo': '🎉 Sorteo Semanal',
    'sorteo-desc-1': 'Todos los sábados sorteamos una cena completa para 4 personas en los mejores restaurantes de la costa uruguaya.',
    'sorteo-como-participar': '¿Cómo participar?',
    'sorteo-paso-1': 'Hacé una reserva en la app',
    'sorteo-paso-2': 'Al llegar al restaurante, <strong>validá tu código</strong> con el mozo',
    'sorteo-paso-3': '¡Automáticamente entrás en el sorteo del sábado!',
    'sorteo-mas-reservas': 'Cuantas más reservas valides, más chances tenés de ganar.',
    'sorteo-participantes': '🎫 Cargando participantes...',
    'sorteo-proximo': '🏆 Próximo sorteo: este sábado',
    'sorteo-participantes-count': '🎫 {count} reservas participaron esta semana',

    // Restaurante
    'tab-perfil-res': '🏪 Mi Perfil',
    'tab-reservas-res': ' Reservas',
    'tab-menu': '📖 Menú',
    'tab-resenas': '⭐ Reseñas',
    'tab-eventos': '🎉 Eventos',
    'section-datos-restaurante': ' Datos del Restaurante',
    'label-nombre-rest': 'Nombre del restaurante',
    'label-tipo-cocina': 'Tipo de cocina',
    'label-direccion': 'Dirección',
    'label-telefono': 'Teléfono',
    'label-whatsapp': 'WhatsApp',
    'label-rango-precio': 'Rango de precio',
    'label-descripcion': 'Descripción',
    'placeholder-nombre-rest': 'Ej: La Parrilla del Puerto',
    'placeholder-direccion': 'Av. Roosevelt...',
    'placeholder-telefono': '+598...',
    'placeholder-whatsapp': '+598...',
    'placeholder-descripcion': 'Contá sobre tu restaurante...',
    'tipo-cocina-select': '-- Seleccionar --',
    'tipo-parrilla': 'Parrilla/Uruguaya',
    'tipo-mariscos': 'Mariscos',
    'tipo-italiana': 'Italiana',
    'tipo-japonesa': 'Japonesa',
    'tipo-mexicana': 'Mexicana',
    'tipo-internacional': 'Internacional',
    'tipo-vegetariana': 'Vegetariana',
    'tipo-otra': 'Otra',
    'rango-economico': '$ (Económico)',
    'rango-moderado': '$$ (Moderado)',
    'rango-premium': '$$$ (Premium)',
    'btn-guardar-perfil': '💾 Guardar Perfil',
    'perfil-actualizado': 'Perfil actualizado',
    'restaurante-registrado': 'Restaurante registrado (pendiente de aprobación)',
    'section-reservas-recibidas': '📋 Reservas Recibidas',
    'sin-reservas': 'No hay reservas',
    'registro-primero': 'Primero registrá tu restaurante en "Mi Perfil"',
    'cobro-info': '💰 Cobro: ${amount} USD (${personas} x $2)',
    'comision-info': 'Comisiones automáticas: $0.50 partner + $0.50 embajador + $1 fundador',
    'btn-confirmar-asistencia': '✅ Confirmar Asistencia',
    'total-pagar': '💰 Total a pagar este mes',
    'confirmar-asistencia-pregunta': '¿Confirmar asistencia del código {codigo} ({personas} personas)?\n\nSe cobrarán ${amount} USD a tu restaurante.',
    'asistencia-confirmada': '✅ Asistencia confirmada. Cobro: ${amount} USD',
    'menu-proximamente': 'Próximamente: cargar platos, precios y fotos',
    'resenas-proximamente': 'Próximamente: moderar reseñas de clientes',
    'eventos-proximamente': 'Próximamente: publicar cenas show, degustaciones, etc.',

    // Partner
    'section-qr': '📱 Mi QR Personalizado',
    'qr-desc': 'Este QR lleva a los usuarios a la app con tu código integrado',
    'btn-copiar-url': '📋 Copiar URL',
    'url-copiada': 'URL copiada',

    // Embajador
    'tab-stats': '📊 Estadísticas',
    'tab-restaurantes': ' Mis Restaurantes',
    'tab-comision': '💰 Mi Comisión',
    'tab-mis-restaurantes': '🏪 Mis Restaurantes',
    'stat-restaurantes-label': 'Restaurantes registrados',
    'stat-cubiertos-label': 'Cubiertos asistidos',
    'stat-comision-label': 'Comisión acumulada',
    'stat-reservas-label': 'Reservas generadas',
    'sin-comisiones': 'Sin comisiones aún',
    'sin-restaurantes-emb': 'Aún no trajiste restaurantes',
    'sin-restaurantes-partner': 'Aún no hay restaurantes con tu código. Compartí tu QR para que los restaurantes se registren con tu código.',
    'total-acumulado': 'Total acumulado',
    'codigo-embajador-desc': 'Compartí este código con los restaurantes. Ganás <strong>$0.50 USD</strong> por cada cubierto que asista.',
    'codigo-partner-desc': 'Usá este código en tus publicaciones, revistas, radios. Ganás <strong>$0.50 USD</strong> por cada cubierto asistido.',
    'btn-compartir-codigo': '📱 Compartir código por WhatsApp',

    // Footer
    'footer-privacidad': '📋 Política de Privacidad',
    'footer-terminos': '📄 Términos y Condiciones',
    'footer-copy': '© 2026 Sabores Costeros. Todos los derechos reservados.',

    // WhatsApp share messages
    'whatsapp-share-cliente': '¡Mirá esta app de restaurantes de la costa! 🌊️ Descubrí los mejores lugares y participá por cenas gratis. Bajala ahora:',
    'whatsapp-share-reserva': '¡Hice una reserva en {restaurante}! 🍽️ Código: {codigo}. Usá Sabores Costeros para descubrir los mejores restaurantes de la costa 🌊',
    'whatsapp-share-codigo': '¡Sumate a Sabores Costeros! 🌊🍽️ Usá mi código {codigo} al registrarte. Descubrí los mejores restaurantes de la costa y participá por cenas gratis',

    // Misc
    'personas': 'personas',
    'confirmar': 'Confirmar',
    'cancelar': 'Cancelar',
    'guardar': 'Guardar',
    'eliminar': 'Eliminar',
    'editar': 'Editar',
    'busqueda': 'Buscar...',
    'filtro': 'Filtrar',
    'todos': 'Todos',
    'abierto': 'Abierto',
    'cerrado': 'Cerrado',
    'reservas': 'Reservas',
    'bienvenida': 'Bienvenido',
    'acceso-denegado': 'Acceso denegado',
    'error-generico': 'Error'
  },
  pt: {
    // Login
    'app-subtitle': 'Descubra os melhores restaurantes da costa',
    'label-email': 'Email',
    'label-password': 'Senha',
    'label-nombre': 'Nome',
    'label-apellido': 'Sobrenome',
    'label-email-reg': 'Email',
    'label-password-reg': 'Senha',
    'placeholder-email': 'seu@email.com',
    'placeholder-password': 'Senha',
    'placeholder-nombre': 'Seu nome',
    'placeholder-apellido': 'Seu sobrenome',
    'placeholder-email-reg': 'seu@email.com',
    'placeholder-password-reg': 'Mínimo 6 caracteres',
    'placeholder-codigo': 'Ex: EMB001',
    'btn-login': 'Entrar',
    'btn-register': 'Criar conta',
    'text-no-account': 'Não tem conta?',
    'link-register': 'Cadastre-se',
    'text-have-account': 'Já tem conta?',
    'link-login': 'Faça login',
    'role-cliente': '🌊 Turista / Cliente',
    'role-restaurante': '🏪 Dono de restaurante',
    'role-embajador': '🌟 Embaixador (Promotor)',
    'label-role': 'Quero me cadastrar como:',
    'label-codigo-emb': 'Seu código de Embaixador (opcional)',
    'legal-text': 'Ao se cadastrar, você aceita nossa',
    'error-empty-fields': 'Preencha todos os campos',
    'error-weak-password': 'Senha mínimo 6 caracteres',
    'error-email-exists': 'Email já cadastrado',
    'error-invalid-email': 'Email inválido',
    'error-wrong-password': 'Email ou senha incorretos',
    'error-user-not-found': 'Não existe conta com esse email',
    'error-account-deactivated': 'Conta desativada',

    // Navbar y botones globales
    'nav-logout': 'Sair',
    'nav-admin': ' Painel Administrador',
    'nav-cliente': '🌊️ Sabores Costeros',
    'nav-restaurante': '️ Meu Restaurante',
    'nav-partner': '🤝 Painel Parceiro',
    'nav-embajador': '🌟 Painel Embaixador',
    'nav-promotor': '💼 Painel Promotor',
    'nav-user-loading': 'Carregando...',

    // Admin tabs
    'tab-crear': '➕ Criar Usuário',
    'tab-aprobaciones': '✅ Aprovações',
    'tab-usuarios': '👥 Usuários',
    'tab-pagos': '💰 Comissões',
    'tab-sorteo': '🎉 Sorteio',
    'tab-configuracion': '️ Configuração',
    'section-crear': '➕ Criar Admin / Parceiro / Embaixador',
    'section-aprobaciones': '✅ Restaurantes Pendentes de Aprovação',
    'section-usuarios': '👥 Gestão de Usuários',
    'section-pagos': '💰 Registro de Comissões',
    'section-sorteo': '🎉 Sorteio Semanal',
    'section-config': '⚙️ Configuração de Comissões',
    'no-aprobaciones': 'Não há aprovações pendentes',
    'no-usuarios': 'Sem usuários',
    'no-pagos': 'Sem pagamentos registrados',
    'label-new-nombre': 'Nome',
    'label-new-apellido': 'Sobrenome',
    'label-new-email': 'Email',
    'label-new-password': 'Senha',
    'label-new-role': 'Função',
    'label-new-codigo': 'Código único',
    'placeholder-new-nombre': 'Nome',
    'placeholder-new-apellido': 'Sobrenome',
    'placeholder-new-email': 'email@exemplo.com',
    'placeholder-new-password': 'Mínimo 6 caracteres',
    'placeholder-new-codigo': 'Ex: REVISTA01, EMB001',
    'role-admin': ' Administrador',
    'role-partner': '🤝 Parceiro (Revista/Influencer/Rádio)',
    'role-embajador-select': '🌟 Embaixador (Promotor)',
    'btn-crear': '✅ Criar Usuário',
    'btn-activar': 'Ativar',
    'btn-desactivar': 'Desativar',
    'btn-aprobar': '✅ Aprovar',
    'btn-rechazar': '❌ Rejeitar',
    'config-comision-total': 'Comissão total por coberto (USD)',
    'config-comision-fundador': 'Comissão Fundador (USD)',
    'config-comision-embajador': 'Comissão Embaixador (USD)',
    'config-comision-partner': 'Comissão Parceiro (USD)',
    'btn-guardar-config': '💾 Salvar Configuração',
    'config-saved': 'Configuração salva com sucesso',
    'user-activado': 'Usuário ativado',
    'user-desactivado': 'Usuário desativado',
    'restaurante-aprobado': 'Restaurante aprovado',
    'restaurante-rechazado': 'Restaurante rejeitado',
    'resumen-comisiones': '📊 Resumo de Comissões',
    'total-recaudado': '💰 Total arrecadado',
    'total-fundador': '👑 Fundador (você)',
    'total-embajadores': '🌟 Embaixadores',
    'total-partners': '🤝 Parceiros',

    // Cliente tabs
    'tab-restaurantes': '️ Restaurantes',
    'tab-reservas': '📋 Minhas Reservas',
    'tab-sorteo-tab': '🎉 Sorteio',
    'tab-perfil': ' Perfil',
    'banner-sorteo-title': '🎉 SORTEIO SEMANAL!',
    'banner-sorteo-desc': 'Valide seu código ao chegar e participe de um <strong>jantar grátis para 4 pessoas</strong>',
    'banner-sorteo-sub': '🏆 Sorteio todos os sábados · 📍 Nos melhores restaurantes da costa',
    'section-restaurantes': '🍽️ Restaurantes da Costa',
    'section-mis-reservas': '📋 Minhas Reservas',
    'section-perfil': ' Meu Perfil',
    'no-restaurantes': 'Ainda não há restaurantes disponíveis',
    'no-reservas': 'Você não tem reservas ativas',
    'btn-reservar': 'Reservar Mesa',
    'label-fecha': 'Data',
    'label-hora': 'Hora',
    'label-personas': 'Quantidade de pessoas',
    'btn-confirmar-reserva': 'Confirmar Reserva',
    'reserva-confirmada-title': '🎉 Reserva Confirmada!',
    'reserva-codigo-label': 'Seu código de reserva:',
    'reserva-presentar': ' Apresente este código ao chegar',
    'reserva-sorteo-info': '🎉 Valide ao chegar e participe do <strong>sorteio semanal</strong> de um jantar grátis',
    'btn-entendido': 'Entendido',
    'btn-cerrar': 'Fechar',
    'reserva-estado-confirmada': 'Confirmada',
    'reserva-estado-asistida': 'Compareceu ✅',
    'reserva-estado-cancelada': 'Cancelada',
    'estado-label': 'Status',
    'reserva-presentar-banner': '📱 Apresente este código ao chegar',
    'reserva-sorteo-banner': '🎉 Valide para participar do sorteio semanal de um jantar grátis',
    'btn-compartir-whatsapp': '📱 Compartilhar pelo WhatsApp',
    'btn-como-llegar': '️ Como chegar',
    'perfil-nombre-label': 'Nome',
    'perfil-email-label': 'Email',
    'perfil-idioma-label': 'Idioma',
    'perfil-cambiar-idioma': 'Mudar idioma',
    'btn-guardar-idioma': 'Salvar idioma',
    'idioma-es': '🇪🇸 Español',
    'idioma-pt': '🇧 Português',
    'idioma-en': '🇸 English',

    // Sorteo
    'sorteo-titulo': '🎉 Sorteio Semanal',
    'sorteo-desc-1': 'Todos os sábados sorteamos um jantar completo para 4 pessoas nos melhores restaurantes da costa uruguaia.',
    'sorteo-como-participar': 'Como participar?',
    'sorteo-paso-1': 'Faça uma reserva no app',
    'sorteo-paso-2': 'Ao chegar no restaurante, <strong>valide seu código</strong> com o garçom',
    'sorteo-paso-3': 'Automaticamente você entra no sorteio de sábado!',
    'sorteo-mas-reservas': 'Quanto mais reservas validar, mais chances de ganhar.',
    'sorteo-participantes': '🎫 Carregando participantes...',
    'sorteo-proximo': '🏆 Próximo sorteio: este sábado',
    'sorteo-participantes-count': '🎫 {count} reservas participaram esta semana',

    // Restaurante
    'tab-perfil-res': '🏪 Meu Perfil',
    'tab-reservas-res': ' Reservas',
    'tab-menu': '📖 Cardápio',
    'tab-resenas': '⭐ Avaliações',
    'tab-eventos': '🎉 Eventos',
    'section-datos-restaurante': '🏪 Dados do Restaurante',
    'label-nombre-rest': 'Nome do restaurante',
    'label-tipo-cocina': 'Tipo de cozinha',
    'label-direccion': 'Endereço',
    'label-telefono': 'Telefone',
    'label-whatsapp': 'WhatsApp',
    'label-rango-precio': 'Faixa de preço',
    'label-descripcion': 'Descrição',
    'placeholder-nombre-rest': 'Ex: A Parrilla do Porto',
    'placeholder-direccion': 'Av. Roosevelt...',
    'placeholder-telefono': '+598...',
    'placeholder-whatsapp': '+598...',
    'placeholder-descripcion': 'Conte sobre seu restaurante...',
    'tipo-cocina-select': '-- Selecionar --',
    'tipo-parrilla': 'Parrilla/Uruguaia',
    'tipo-mariscos': 'Frutos do Mar',
    'tipo-italiana': 'Italiana',
    'tipo-japonesa': 'Japonesa',
    'tipo-mexicana': 'Mexicana',
    'tipo-internacional': 'Internacional',
    'tipo-vegetariana': 'Vegetariana',
    'tipo-otra': 'Outra',
    'rango-economico': '$ (Econômico)',
    'rango-moderado': '$$ (Moderado)',
    'rango-premium': '$$$ (Premium)',
    'btn-guardar-perfil': ' Salvar Perfil',
    'perfil-actualizado': 'Perfil atualizado',
    'restaurante-registrado': 'Restaurante registrado (pendente de aprovação)',
    'section-reservas-recibidas': '📋 Reservas Recebidas',
    'sin-reservas': 'Não há reservas',
    'registro-primero': 'Primeiro registre seu restaurante em "Meu Perfil"',
    'cobro-info': '💰 Cobrança: ${amount} USD (${personas} x $2)',
    'comision-info': 'Comissões automáticas: $0.50 parceiro + $0.50 embaixador + $1 fundador',
    'btn-confirmar-asistencia': '✅ Confirmar Presença',
    'total-pagar': '💰 Total a pagar este mês',
    'confirmar-asistencia-pregunta': 'Confirmar presença do código {codigo} ({personas} pessoas)?\n\nSerão cobrados ${amount} USD do seu restaurante.',
    'asistencia-confirmada': '✅ Presença confirmada. Cobrança: ${amount} USD',
    'menu-proximamente': 'Em breve: carregar pratos, preços e fotos',
    'resenas-proximamente': 'Em breve: moderar avaliações de clientes',
    'eventos-proximamente': 'Em breve: publicar jantares show, degustações, etc.',

    // Partner
    'section-qr': '📱 Meu QR Personalizado',
    'qr-desc': 'Este QR leva os usuários ao app com seu código integrado',
    'btn-copiar-url': ' Copiar URL',
    'url-copiada': 'URL copiada',

    // Embajador
    'tab-stats': ' Estatísticas',
    'tab-restaurantes': '🏪 Meus Restaurantes',
    'tab-comision': '💰 Minha Comissão',
    'tab-mis-restaurantes': '🏪 Meus Restaurantes',
    'stat-restaurantes-label': 'Restaurantes registrados',
    'stat-cubiertos-label': 'Cobertos presentes',
    'stat-comision-label': 'Comissão acumulada',
    'stat-reservas-label': 'Reservas geradas',
    'sin-comisiones': 'Sem comissões ainda',
    'sin-restaurantes-emb': 'Ainda não trouxe restaurantes',
    'sin-restaurantes-partner': 'Ainda não há restaurantes com seu código. Compartilhe seu QR para que os restaurantes se registrem com seu código.',
    'total-acumulado': 'Total acumulado',
    'codigo-embajador-desc': 'Compartilhe este código com os restaurantes. Ganhe <strong>$0.50 USD</strong> por cada coberto presente.',
    'codigo-partner-desc': 'Use este código em suas publicações, revistas, rádios. Ganhe <strong>$0.50 USD</strong> por cada coberto presente.',
    'btn-compartir-codigo': '📱 Compartilhar código pelo WhatsApp',

    // Footer
    'footer-privacidad': '📋 Política de Privacidade',
    'footer-terminos': '📄 Termos e Condições',
    'footer-copy': '© 2026 Sabores Costeros. Todos os direitos reservados.',

    // WhatsApp share messages
    'whatsapp-share-cliente': 'Olhe este app de restaurantes da costa! 🌊🍽️ Descubra os melhores lugares e participe de jantares grátis. Baixe agora:',
    'whatsapp-share-reserva': 'Fiz uma reserva no {restaurante}! 🍽️ Código: {codigo}. Use Sabores Costeros para descobrir os melhores restaurantes da costa 🌊',
    'whatsapp-share-codigo': 'Junte-se ao Sabores Costeros! 🌊🍽️ Use meu código {codigo} ao se cadastrar. Descubra os melhores restaurantes da costa e participe de jantares grátis',

    // Misc
    'personas': 'pessoas',
    'confirmar': 'Confirmar',
    'cancelar': 'Cancelar',
    'guardar': 'Salvar',
    'eliminar': 'Excluir',
    'editar': 'Editar',
    'busqueda': 'Buscar...',
    'filtro': 'Filtrar',
    'todos': 'Todos',
    'abierto': 'Aberto',
    'cerrado': 'Fechado',
    'reservas': 'Reservas',
    'bienvenida': 'Bem-vindo',
    'acceso-denegado': 'Acesso negado',
    'error-generico': 'Erro'
  },
  en: {
    // Login
    'app-subtitle': 'Discover the best restaurants on the coast',
    'label-email': 'Email',
    'label-password': 'Password',
    'label-nombre': 'First Name',
    'label-apellido': 'Last Name',
    'label-email-reg': 'Email',
    'label-password-reg': 'Password',
    'placeholder-email': 'your@email.com',
    'placeholder-password': 'Password',
    'placeholder-nombre': 'Your name',
    'placeholder-apellido': 'Your last name',
    'placeholder-email-reg': 'your@email.com',
    'placeholder-password-reg': 'Minimum 6 characters',
    'placeholder-codigo': 'Eg: EMB001',
    'btn-login': 'Sign In',
    'btn-register': 'Create Account',
    'text-no-account': "Don't have an account?",
    'link-register': 'Sign Up',
    'text-have-account': 'Already have an account?',
    'link-login': 'Sign In',
    'role-cliente': '🌊 Tourist / Customer',
    'role-restaurante': ' Restaurant Owner',
    'role-embajador': '🌟 Ambassador (Promoter)',
    'label-role': 'I want to register as:',
    'label-codigo-emb': 'Your Ambassador code (optional)',
    'legal-text': 'By registering, you accept our',
    'error-empty-fields': 'Fill in all fields',
    'error-weak-password': 'Password minimum 6 characters',
    'error-email-exists': 'Email already registered',
    'error-invalid-email': 'Invalid email',
    'error-wrong-password': 'Incorrect email or password',
    'error-user-not-found': 'No account with that email',
    'error-account-deactivated': 'Account deactivated',

    // Navbar y botones globales
    'nav-logout': 'Logout',
    'nav-admin': '👑 Admin Panel',
    'nav-cliente': '🌊️ Sabores Costeros',
    'nav-restaurante': '️ My Restaurant',
    'nav-partner': '🤝 Partner Panel',
    'nav-embajador': '🌟 Ambassador Panel',
    'nav-promotor': '💼 Promoter Panel',
    'nav-user-loading': 'Loading...',

    // Admin tabs
    'tab-crear': '➕ Create User',
    'tab-aprobaciones': '✅ Approvals',
    'tab-usuarios': '👥 Users',
    'tab-pagos': '💰 Commissions',
    'tab-sorteo': ' Raffle',
    'tab-configuracion': '⚙️ Settings',
    'section-crear': '➕ Create Admin / Partner / Ambassador',
    'section-aprobaciones': '✅ Restaurants Pending Approval',
    'section-usuarios': '👥 User Management',
    'section-pagos': '💰 Commission Records',
    'section-sorteo': '🎉 Weekly Raffle',
    'section-config': '⚙️ Commission Settings',
    'no-aprobaciones': 'No pending approvals',
    'no-usuarios': 'No users',
    'no-pagos': 'No payments registered',
    'label-new-nombre': 'First Name',
    'label-new-apellido': 'Last Name',
    'label-new-email': 'Email',
    'label-new-password': 'Password',
    'label-new-role': 'Role',
    'label-new-codigo': 'Unique Code',
    'placeholder-new-nombre': 'First Name',
    'placeholder-new-apellido': 'Last Name',
    'placeholder-new-email': 'email@example.com',
    'placeholder-new-password': 'Minimum 6 characters',
    'placeholder-new-codigo': 'Eg: REVISTA01, EMB001',
    'role-admin': ' Administrator',
    'role-partner': ' Partner (Magazine/Influencer/Radio)',
    'role-embajador-select': '🌟 Ambassador (Promoter)',
    'btn-crear': '✅ Create User',
    'btn-activar': 'Activate',
    'btn-desactivar': 'Deactivate',
    'btn-aprobar': '✅ Approve',
    'btn-rechazar': '❌ Reject',
    'config-comision-total': 'Total commission per cover (USD)',
    'config-comision-fundador': 'Founder Commission (USD)',
    'config-comision-embajador': 'Ambassador Commission (USD)',
    'config-comision-partner': 'Partner Commission (USD)',
    'btn-guardar-config': '💾 Save Settings',
    'config-saved': 'Settings saved successfully',
    'user-activado': 'User activated',
    'user-desactivado': 'User deactivated',
    'restaurante-aprobado': 'Restaurant approved',
    'restaurante-rechazado': 'Restaurant rejected',
    'resumen-comisiones': '📊 Commission Summary',
    'total-recaudado': '💰 Total collected',
    'total-fundador': '👑 Founder (you)',
    'total-embajadores': '🌟 Ambassadors',
    'total-partners': '🤝 Partners',

    // Cliente tabs
    'tab-restaurantes': '🍽️ Restaurants',
    'tab-reservas': ' My Reservations',
    'tab-sorteo-tab': '🎉 Raffle',
    'tab-perfil': '👤 Profile',
    'banner-sorteo-title': ' WEEKLY RAFFLE!',
    'banner-sorteo-desc': 'Validate your code upon arrival and enter for a <strong>free dinner for 4 people</strong>',
    'banner-sorteo-sub': '🏆 Raffle every Saturday · 📍 At the best coastal restaurants',
    'section-restaurantes': '🍽️ Coastal Restaurants',
    'section-mis-reservas': '📋 My Reservations',
    'section-perfil': '👤 My Profile',
    'no-restaurantes': 'No restaurants available yet',
    'no-reservas': 'You have no active reservations',
    'btn-reservar': 'Book a Table',
    'label-fecha': 'Date',
    'label-hora': 'Time',
    'label-personas': 'Number of people',
    'btn-confirmar-reserva': 'Confirm Reservation',
    'reserva-confirmada-title': '🎉 Reservation Confirmed!',
    'reserva-codigo-label': 'Your booking code:',
    'reserva-presentar': '📱 Present this code upon arrival',
    'reserva-sorteo-info': '🎉 Validate upon arrival and enter the <strong>weekly raffle</strong> for a free dinner',
    'btn-entendido': 'Got it',
    'btn-cerrar': 'Close',
    'reserva-estado-confirmada': 'Confirmed',
    'reserva-estado-asistida': 'Attended ✅',
    'reserva-estado-cancelada': 'Cancelled',
    'estado-label': 'Status',
    'reserva-presentar-banner': '📱 Present this code upon arrival',
    'reserva-sorteo-banner': '🎉 Validate to enter the weekly free dinner raffle',
    'btn-compartir-whatsapp': '📱 Share via WhatsApp',
    'btn-como-llegar': '🗺️ How to get there',
    'perfil-nombre-label': 'Name',
    'perfil-email-label': 'Email',
    'perfil-idioma-label': 'Language',
    'perfil-cambiar-idioma': 'Change language',
    'btn-guardar-idioma': 'Save language',
    'idioma-es': '🇸 Español',
    'idioma-pt': '🇧🇷 Português',
    'idioma-en': '🇺 English',

    // Sorteo
    'sorteo-titulo': '🎉 Weekly Raffle',
    'sorteo-desc-1': 'Every Saturday we raffle a complete dinner for 4 people at the best restaurants on the Uruguayan coast.',
    'sorteo-como-participar': 'How to participate?',
    'sorteo-paso-1': 'Make a reservation on the app',
    'sorteo-paso-2': 'When arriving at the restaurant, <strong>validate your code</strong> with the waiter',
    'sorteo-paso-3': 'You automatically enter the Saturday raffle!',
    'sorteo-mas-reservas': 'The more reservations you validate, the more chances you have to win.',
    'sorteo-participantes': '🎫 Loading participants...',
    'sorteo-proximo': '🏆 Next raffle: this Saturday',
    'sorteo-participantes-count': '🎫 {count} reservations participated this week',

    // Restaurante
    'tab-perfil-res': '🏪 My Profile',
    'tab-reservas-res': ' Reservations',
    'tab-menu': '📖 Menu',
    'tab-resenas': '⭐ Reviews',
    'tab-eventos': '🎉 Events',
    'section-datos-restaurante': '🏪 Restaurant Details',
    'label-nombre-rest': 'Restaurant name',
    'label-tipo-cocina': 'Cuisine type',
    'label-direccion': 'Address',
    'label-telefono': 'Phone',
    'label-whatsapp': 'WhatsApp',
    'label-rango-precio': 'Price range',
    'label-descripcion': 'Description',
    'placeholder-nombre-rest': 'Eg: The Port Grill',
    'placeholder-direccion': 'Av. Roosevelt...',
    'placeholder-telefono': '+598...',
    'placeholder-whatsapp': '+598...',
    'placeholder-descripcion': 'Tell us about your restaurant...',
    'tipo-cocina-select': '-- Select --',
    'tipo-parrilla': 'Grill/Uruguayan',
    'tipo-mariscos': 'Seafood',
    'tipo-italiana': 'Italian',
    'tipo-japonesa': 'Japanese',
    'tipo-mexicana': 'Mexican',
    'tipo-internacional': 'International',
    'tipo-vegetariana': 'Vegetarian',
    'tipo-otra': 'Other',
    'rango-economico': '$ (Budget)',
    'rango-moderado': '$$ (Moderate)',
    'rango-premium': '$$$ (Premium)',
    'btn-guardar-perfil': ' Save Profile',
    'perfil-actualizado': 'Profile updated',
    'restaurante-registrado': 'Restaurant registered (pending approval)',
    'section-reservas-recibidas': '📋 Reservations Received',
    'sin-reservas': 'No reservations',
    'registro-primero': 'First register your restaurant in "My Profile"',
    'cobro-info': '💰 Charge: ${amount} USD (${personas} x $2)',
    'comision-info': 'Automatic commissions: $0.50 partner + $0.50 ambassador + $1 founder',
    'btn-confirmar-asistencia': '✅ Confirm Attendance',
    'total-pagar': '💰 Total to pay this month',
    'confirmar-asistencia-pregunta': 'Confirm attendance for code {codigo} ({personas} people)?\n\n${amount} USD will be charged to your restaurant.',
    'asistencia-confirmada': '✅ Attendance confirmed. Charge: ${amount} USD',
    'menu-proximamente': 'Coming soon: upload dishes, prices and photos',
    'resenas-proximamente': 'Coming soon: moderate customer reviews',
    'eventos-proximamente': 'Coming soon: publish dinner shows, tastings, etc.',

    // Partner
    'section-qr': '📱 My Custom QR',
    'qr-desc': 'This QR takes users to the app with your code integrated',
    'btn-copiar-url': '📋 Copy URL',
    'url-copiada': 'URL copied',

    // Embajador
    'tab-stats': ' Statistics',
    'tab-restaurantes': '🏪 My Restaurants',
    'tab-comision': '💰 My Commission',
    'tab-mis-restaurantes': '🏪 My Restaurants',
    'stat-restaurantes-label': 'Registered restaurants',
    'stat-cubiertos-label': 'Covers attended',
    'stat-comision-label': 'Accumulated commission',
    'stat-reservas-label': 'Reservations generated',
    'sin-comisiones': 'No commissions yet',
    'sin-restaurantes-emb': 'You haven\'t brought restaurants yet',
    'sin-restaurantes-partner': 'No restaurants with your code yet. Share your QR so restaurants register with your code.',
    'total-acumulado': 'Total accumulated',
    'codigo-embajador-desc': 'Share this code with restaurants. Earn <strong>$0.50 USD</strong> per cover attended.',
    'codigo-partner-desc': 'Use this code in your publications, magazines, radios. Earn <strong>$0.50 USD</strong> per cover attended.',
    'btn-compartir-codigo': '📱 Share code via WhatsApp',

    // Footer
    'footer-privacidad': '📋 Privacy Policy',
    'footer-terminos': '📄 Terms and Conditions',
    'footer-copy': '© 2026 Sabores Costeros. All rights reserved.',

    // WhatsApp share messages
    'whatsapp-share-cliente': 'Check out this coastal restaurant app! 🍽️ Discover the best spots and win free dinners. Download now:',
    'whatsapp-share-reserva': 'I made a reservation at {restaurante}! 🍽️ Code: {codigo}. Use Sabores Costeros to discover the best coastal restaurants 🌊',
    'whatsapp-share-codigo': 'Join Sabores Costeros! 🌊🍽️ Use my code {codigo} when signing up. Discover the best coastal restaurants and win free dinners',

    // Misc
    'personas': 'people',
    'confirmar': 'Confirm',
    'cancelar': 'Cancel',
    'guardar': 'Save',
    'eliminar': 'Delete',
    'editar': 'Edit',
    'busqueda': 'Search...',
    'filtro': 'Filter',
    'todos': 'All',
    'abierto': 'Open',
    'cerrado': 'Closed',
    'reservas': 'Reservations',
    'bienvenida': 'Welcome',
    'acceso-denegado': 'Access denied',
    'error-generico': 'Error'
  }
};

let idiomaActual = sessionStorage.getItem('idioma') || 'es';

export function t(clave) {
  const trad = traducciones[idiomaActual]?.[clave] || traducciones['es']?.[clave] || clave;
  return trad;
}

export function cambiarIdioma(nuevoIdioma) {
  idiomaActual = nuevoIdioma;
  sessionStorage.setItem('idioma', nuevoIdioma);
  applyTranslations();
}

export function getIdiomaActual() {
  return idiomaActual;
}

// Aplicar traducciones a todos los elementos con data-i18n
export function applyTranslations() {
  // Traducir textContent
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const clave = el.getAttribute('data-i18n');
    const traduccion = t(clave);
    // Solo reemplazar si hay traducción disponible
    if (traduccion && traduccion !== clave) {
      if (traduccion.includes('<')) {
        el.innerHTML = traduccion;
      } else {
        el.textContent = traduccion;
      }
    }
  });
  
  // Traducir placeholders
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const clave = el.getAttribute('data-i18n-placeholder');
    const traduccion = t(clave);
    if (traduccion && traduccion !== clave) {
      el.placeholder = traduccion;
    }
  });
  
  // Actualizar botones de idioma activos
  document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
  const btnActivo = document.getElementById('btn-' + idiomaActual);
  if (btnActivo) btnActivo.classList.add('active');

  // Actualizar selects de idioma
  document.querySelectorAll('#selector-idioma').forEach(sel => {
    sel.value = idiomaActual;
  });

  // Actualizar el atributo lang del html
  document.documentElement.lang = idiomaActual;
}

// ========== UTILIDADES ==========
export function showAlert(message, type = 'info') {
  const colors = {
    success: '#28A745',
    danger: '#DC3545',
    warning: '#FFC107',
    info: '#17A2B8'
  };

  const div = document.createElement('div');
  div.style.cssText = `
    position:fixed;top:20px;right:20px;z-index:9999;
    padding:15px 25px;border-radius:8px;color:white;
    font-weight:600;background:${colors[type] || colors.info};
    box-shadow:0 4px 15px rgba(0,0,0,0.3);
    animation: slideIn 0.3s ease;
  `;
  div.textContent = message;
  document.body.appendChild(div);

  setTimeout(() => {
    div.style.opacity = '0';
    setTimeout(() => div.remove(), 300);
  }, 4000);
}

export function generarCodigoReserva() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let codigo = 'SC-';
  for (let i = 0; i < 4; i++) {
    codigo += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return codigo;
}

export function formatDate(timestamp) {
  if (!timestamp) return '—';
  try {
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    if (isNaN(date.getTime())) return '—';
    return date.toLocaleString('es-ES', {
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  } catch {
    return '—';
  }
}

// Compartir por WhatsApp
export function compartirWhatsApp(mensaje, url) {
  const texto = encodeURIComponent(mensaje + '\n' + url);
  window.open(`https://wa.me/?text=${texto}`, '_blank');
}

// Abrir Google Maps
export function abrirGoogleMaps(direccion) {
  const query = encodeURIComponent(direccion);
  window.open(`https://www.google.com/maps/search/?api=1&query=${query}`, '_blank');
}

// CSS animation
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from { transform: translateX(400px); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
`;
document.head.appendChild(style);
